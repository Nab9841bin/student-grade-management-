#ifndef UTILS_H
#define UTILS_H

int isValidRoll(int roll);

#endif
