#include "../include/utils.h"

int isValidRoll(int roll) {
    return roll > 0;
}
