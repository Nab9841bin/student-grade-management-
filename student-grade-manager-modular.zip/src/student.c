#include <stdio.h>
#include <string.h>
#include "../include/student.h"
#include "../include/utils.h"

char calculateGrade(float marks) {
    if (marks >= 90) return 'A';
    else if (marks >= 75) return 'B';
    else if (marks >= 60) return 'C';
    else if (marks >= 45) return 'D';
    else return 'F';
}

void addStudent(Student students[], int *count) {
    printf("\nEnter Roll Number: ");
    scanf("%d", &students[*count].roll);

    if (!isValidRoll(students[*count].roll)) {
        printf("❌ Invalid roll number!\n");
        return;
    }

    printf("Enter Name: ");
    scanf(" %[^
]", students[*count].name);

    printf("Enter Marks: ");
    scanf("%f", &students[*count].marks);

    students[*count].grade = calculateGrade(students[*count].marks);
    (*count)++;

    printf("✅ Student added successfully!\n");
}

void displayStudents(Student students[], int count) {
    if (count == 0) {
        printf("\nNo students to display!\n");
        return;
    }

    printf("\n%-10s %-20s %-10s %-10s\n", "Roll No", "Name", "Marks", "Grade");
    printf("------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        printf("%-10d %-20s %-10.2f %-10c\n",
               students[i].roll,
               students[i].name,
               students[i].marks,
               students[i].grade);
    }
}

void searchStudent(Student students[], int count, int roll) {
    for (int i = 0; i < count; i++) {
        if (students[i].roll == roll) {
            printf("\nStudent Found:\n");
            printf("Roll: %d\nName: %s\nMarks: %.2f\nGrade: %c\n",
                   students[i].roll, students[i].name,
                   students[i].marks, students[i].grade);
            return;
        }
    }
    printf("\n❌ Student with Roll %d not found!\n", roll);
}

void updateStudent(Student students[], int count, int roll) {
    for (int i = 0; i < count; i++) {
        if (students[i].roll == roll) {
            printf("\nEnter New Name: ");
            scanf(" %[^
]", students[i].name);
            printf("Enter New Marks: ");
            scanf("%f", &students[i].marks);
            students[i].grade = calculateGrade(students[i].marks);
            printf("✅ Student updated successfully!\n");
            return;
        }
    }
    printf("\n❌ Student with Roll %d not found!\n", roll);
}
