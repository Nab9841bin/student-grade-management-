# Student Grade Management System

## 📌 Overview
A console-based C program to manage student records.

### Features
- Add student
- Display students
- Search by roll number
- Update student info
- Auto grade assignment

## 📂 Folder Structure
```
student-grade-manager/
│── src/       → main.c, student.c, utils.c
│── include/   → student.h, utils.h
│── Makefile
│── README.md
```

## 🚀 Build & Run
```bash
make
./student_manager
```
